 
INSERT INTO `users` VALUES 
 (4,'','Paul@Cookies.com','Paul','Bearer',7,'Paul'),
(1,'','Sean@Cookies.com','Sean','Smith',1,'Sean');
 